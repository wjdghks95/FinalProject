package com.kh.lawservice101.client.controller;

import com.kh.lawservice101.client.model.dao.ClientDAO;
import com.kh.lawservice101.client.model.service.ClientService;
import com.kh.lawservice101.client.model.service.ClientServiceImpl;
import com.kh.lawservice101.client.model.vo.ClientVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class ClientJoinController {
    private final ClientService clientService;

    @GetMapping("/clientJoin")
    public String clientJoin() {
        return "clientJoin";
    }

    @PostMapping("/client/insert.do")
    public String insert(@ModelAttribute ClientVO clientVO) {
        clientService.saveClient(clientVO);
        return "redirect:/clientJoin";
    }
}
