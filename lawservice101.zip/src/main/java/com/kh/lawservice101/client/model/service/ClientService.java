package com.kh.lawservice101.client.model.service;

import com.kh.lawservice101.client.model.vo.ClientVO;

public interface ClientService {
    void saveClient( ClientVO clientVO);

}
