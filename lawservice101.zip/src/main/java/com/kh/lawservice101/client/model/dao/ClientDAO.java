package com.kh.lawservice101.client.model.dao;

import com.kh.lawservice101.client.model.vo.ClientVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ClientDAO {

    void insertClient(ClientVO clientVO);
}
