package com.kh.lawservice101.client.model.service;

import com.kh.lawservice101.client.model.dao.ClientDAO;
import com.kh.lawservice101.client.model.vo.ClientVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class ClientServiceImpl implements ClientService {
    private final ClientDAO clientDAO;

    @Override
    public void saveClient(ClientVO clientVO) {
        clientDAO.insertClient(clientVO);
    }

}
