package com.kh.lawservice101;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LawService101Application {

	public static void main(String[] args) {
		SpringApplication.run(LawService101Application.class, args);
	}

}
