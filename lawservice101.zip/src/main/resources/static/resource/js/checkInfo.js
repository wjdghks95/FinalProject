function btnActive(frm){
    if(frm.checkButton.disabled==true){
        frm.checkButton.disabled=false;
    }else{
        frm.checkButton.disabled=true;
    }
}
